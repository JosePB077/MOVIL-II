package com.example.telefonia

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.PhoneStateListener
import android.telephony.ServiceState
import android.telephony.SignalStrength
import android.telephony.SmsManager
import android.telephony.TelephonyManager
import android.util.Log
import android.widget.Toast
import com.example.telefonia.ui.theme.Telefono

class BroadcastReciver: BroadcastReceiver() {
    private var mListener: ServiceStateListener? = null
    private var mTelephonyManager: TelephonyManager? = null
    private var mContext: Context? = null

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        mContext = context

        if (action == TelephonyManager.ACTION_PHONE_STATE_CHANGED) {
            mTelephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            val ExtraerNumero = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
            if (ExtraerNumero != null) {
                Toast.makeText(
                    mContext,
                    "Numero entrante : ${ExtraerNumero.toString()}",
                    Toast.LENGTH_LONG
                ).show()
                EnviarMensaje(ExtraerNumero)
            }
            Toast.makeText(mContext, "¡Receptor registrado!", Toast.LENGTH_LONG).show()
            mListener = ServiceStateListener()
            mTelephonyManager?.listen(mListener, PhoneStateListener.LISTEN_SERVICE_STATE)
        }
        Log.d("Llamada detectada","Se detecto")
    }
    private fun EnviarMensaje(numero: String) {
        val smsMensaje = SmsManager.getDefault()
        val mensaje = Telefono.Telefono.mensaje
        if (numero==Telefono.Telefono.numero){
            smsMensaje.sendTextMessage(numero,null,mensaje,null,null)
            Log.d("Mensaje Enviado",smsMensaje.toString())
        }
    }
    var connected=false
    private inner class ServiceStateListener : PhoneStateListener() {
        override fun onServiceStateChanged(serviceState: ServiceState) {
            if (connected==false || serviceState.state == ServiceState.STATE_IN_SERVICE){
                connected=true

                if (connected) {
                    Toast.makeText(mContext, "¡Conexión establecida!", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(mContext, "¡Conexión perdida!", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}