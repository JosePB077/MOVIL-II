package com.example.telefonia.ui.theme.viewModel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.example.telefonia.BroadcastReciver
import com.example.telefonia.ui.theme.Telefono

class ViewModelMsj (): ViewModel() {
    var Mensaje by mutableStateOf("Mensaje Inicial")
    var Numero by mutableStateOf("")

    fun updateMensaje(value: String){
        Mensaje = value
        Telefono.Telefono.mensaje=value
    }
    fun updateNumero(value: String){
        Numero = value
        Telefono.Telefono.numero=value
    }
}