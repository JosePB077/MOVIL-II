package com.example.telefonia.ui.theme

class Telefono {
    object Telefono{
        var mensaje="Mensaje Inicial"
        var numero=""
    }
}